library(testthat)
library(exuberdata)

test_check("exuberdata")
