r
# exuberdata

<!-- badges: start -->
<!-- badges: end -->

The goal of exuberdata is to ...

## Installation

You can install the released version of exuberdata from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("exuberdata")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(exuberdata)
## basic example code
```

