# library(drat)
# addRepo("kvasilopoulos")
# insertPackage("exuberdata_0.0.0.9000.tar.gz")
# install.packages("exuberdata", repos = "https://kvasilopoulos.github.io/drat/", 
# type = "source")