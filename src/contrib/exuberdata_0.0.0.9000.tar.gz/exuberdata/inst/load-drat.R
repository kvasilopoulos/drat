x <- build()
library(drat)
addRepo("kvasilopoulos")
insertPackage(x)

library(git2r)
drat_repo <- repository("~/git/drat")

add(drat_repo, ".")
commit(drat_repo, "Update Data")


push(drat_repo, name = "origin", refspec = "refs/heads/gh-pages",
     credentials = cred, set_upstream = TRUE)

install.packages("exuberdata", repos = "https://kvasilopoulos.github.io/drat/", type = "source")